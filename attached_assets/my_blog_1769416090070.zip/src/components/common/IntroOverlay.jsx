import React, { useEffect, useState, useRef, useMemo } from "react";
import { AnimatePresence, motion, useAnimation } from "framer-motion";

const IntroOverlay = ({
  onComplete,
  playOnceKey = "introPlayed",
  durationMs = 6000,
}) => {
  const [show, setShow] = useState(true);
  const [phase, setPhase] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const containerRef = useRef(null);
  const mousePos = useRef({ x: 0, y: 0 });
  const controls = useAnimation();

  // 3D 입자 데이터 생성
  const particles = useMemo(() => {
    return [...Array(50)].map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      z: Math.random() * 1000 - 500,
      size: Math.random() * 4 + 1,
      speed: Math.random() * 2 + 0.5,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.8 + 0.2,
    }));
  }, []);

  // 고급 마우스 추적 효과
  useEffect(() => {
    const handleMouseMove = (e) => {
      mousePos.current = { x: e.clientX, y: e.clientY };

      // 3D 패럴랙스 효과
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
        const y = (e.clientY - rect.top - rect.height / 2) / rect.height;

        controls.start({
          x: x * 20,
          y: y * 20,
          transition: { type: "spring", stiffness: 100, damping: 30 },
        });
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [controls]);

  // 고급 타이밍 시스템
  useEffect(() => {
    // 세션 체크
    try {
      if (playOnceKey && typeof window !== "undefined") {
        const played = window.sessionStorage.getItem(playOnceKey);
        if (played === "1") {
          setShow(false);
          onComplete?.();
          return;
        }
      }
    } catch (_) {}

    // 프리미엄 타이밍 시퀀스
    const timingSequence = [
      setTimeout(() => setPhase(1), 1200),
      setTimeout(() => setPhase(2), 2800),
      setTimeout(() => setPhase(3), 4500),
      setTimeout(() => {
        setPhase(4);
        setIsTransitioning(true);
      }, 5800),
    ];

    // 종료 시퀀스
    const exitTimer = setTimeout(() => {
      setShow(false);
      try {
        if (playOnceKey && typeof window !== "undefined") {
          window.sessionStorage.setItem(playOnceKey, "1");
        }
      } catch (_) {}
      onComplete?.();
    }, durationMs);

    return () => {
      timingSequence.forEach(clearTimeout);
      clearTimeout(exitTimer);
    };
  }, [onComplete, playOnceKey, durationMs]);

  // 고급 배경 효과
  const BackgroundEffect = () => (
    <>
      {/* 3D 입자 배경 */}
      <div className="absolute inset-0 overflow-hidden">
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className={`absolute rounded-full ${
              phase >= 3
                ? "bg-gradient-to-r from-gray-300 to-gray-100"
                : "bg-gradient-to-r from-cyan-400 via-blue-500 to-violet-500"
            }`}
            style={{
              width: particle.size,
              height: particle.size,
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              filter: "blur(0.5px)",
            }}
            animate={{
              opacity: phase >= 3 ? [0, 0.3, 0] : [0, particle.opacity, 0],
              scale: [0, 1.2, 0],
              x: [0, particle.x * 0.1, 0],
              y: [0, particle.y * 0.1, 0],
            }}
            transition={{
              duration: particle.speed * 4,
              delay: particle.delay,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* 시너지 웨이브 효과 */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {[...Array(3)].map((_, i) => (
          <motion.circle
            key={i}
            cx="50%"
            cy="50%"
            r="30%"
            fill="none"
            stroke={
              phase >= 3
                ? "rgba(150, 150, 150, 0.1)"
                : "rgba(120, 119, 198, 0.2)"
            }
            strokeWidth="1"
            filter="url(#glow)"
            animate={{
              r: ["30%", "70%", "30%"],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 6 + i,
              delay: i * 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </svg>
    </>
  );

  // 3D 메인 오브젝트
  const MainObject = () => (
    <motion.div
      initial={{ scale: 0.5, rotateY: -180, rotateX: 45 }}
      animate={{
        scale: phase >= 3 ? 0.4 : 1,
        rotateY: 0,
        rotateX: 0,
      }}
      transition={{
        duration: 4,
        ease: [0.23, 1, 0.32, 1],
        scale: { delay: 0.8 },
      }}
      style={{ transformStyle: "preserve-3d" }}
      className="relative"
    >
      {/* 메인 코어 */}
      <motion.div
        animate={controls}
        className="relative w-32 h-32 rounded-full backdrop-blur-3xl border"
        style={{
          background:
            phase >= 3
              ? "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.4), rgba(245,245,245,0.1))"
              : "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.3), rgba(0,0,0,0.1))",
          borderColor:
            phase >= 3 ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.2)",
          boxShadow:
            phase >= 3
              ? "0 0 50px rgba(200,200,200,0.3), inset 0 0 30px rgba(255,255,255,0.1)"
              : "0 0 80px rgba(120,119,198,0.6), inset 0 0 30px rgba(255,255,255,0.2)",
        }}
      >
        {/* 내불 유동적 패턴 */}
        <motion.div
          className="absolute inset-6 rounded-full overflow-hidden"
          animate={{ rotate: phase >= 3 ? 0 : 360 }}
          transition={{
            duration: phase >= 3 ? 3 : 30,
            ease: "linear",
          }}
        >
          <div
            className={`absolute inset-0 ${
              phase >= 3
                ? "bg-gradient-to-br from-gray-200/20 via-transparent to-gray-300/20"
                : "bg-gradient-to-br from-cyan-400/20 via-transparent to-violet-400/20"
            }`}
          />
        </motion.div>

        {/* 중심 코어 */}
        <motion.div
          animate={{
            scale: phase >= 3 ? 0.8 : [1, 1.4, 1],
            opacity: phase >= 3 ? 0.7 : [1, 0.7, 1],
            rotate: phase >= 3 ? 0 : 360,
          }}
          transition={{
            duration: phase >= 3 ? 3 : 4,
            repeat: phase >= 3 ? 0 : Infinity,
            ease: "easeInOut",
          }}
          className={`absolute top-1/2 left-1/2 w-3 h-3 rounded-full -translate-x-1/2 -translate-y-1/2 ${
            phase >= 3 ? "bg-gray-300" : "bg-white"
          }`}
          style={{
            boxShadow:
              phase >= 3
                ? "0 0 20px rgba(200,200,200,0.8)"
                : "0 0 30px rgba(255,255,255,0.9)",
          }}
        />
      </motion.div>

      {/* 주변 입자들 */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className={`absolute w-2 h-2 rounded-full ${
            phase >= 3 ? "bg-gray-400" : "bg-white"
          }`}
          style={{
            left: "50%",
            top: "50%",
            transform: "translate(-50%, -50%)",
          }}
          animate={{
            x: [0, Math.cos((i * 60 * Math.PI) / 180) * 60, 0],
            y: [0, Math.sin((i * 60 * Math.PI) / 180) * 60, 0],
            opacity: [0.8, 0.3, 0.8],
            scale: [0.8, 0.4, 0.8],
          }}
          transition={{
            duration: 3,
            delay: i * 0.2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </motion.div>
  );

  // 텍스트 애니메이션 컴포넌트
  const TextContent = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{
        opacity: phase >= 2.5 ? 1 : phase >= 1 ? 0.4 : 0,
        y: phase >= 3.5 ? -100 : phase >= 2 ? 0 : 30,
      }}
      transition={{
        opacity: { duration: 2.5, ease: "easeOut" },
        y: {
          duration: phase >= 3.5 ? 5 : 2,
          ease: [0.23, 1, 0.32, 1],
        },
      }}
      className="absolute inset-0 flex items-center justify-center pointer-events-none"
    >
      <div className="text-center max-w-3xl px-8">
        <motion.h1
          initial={{ y: 60, opacity: 0 }}
          animate={{
            y: phase >= 2 ? 0 : 60,
            opacity: phase >= 2 ? 1 : 0,
          }}
          transition={{
            duration: 3,
            ease: [0.23, 1, 0.32, 1],
          }}
          className={`text-5xl md:text-7xl font-thin tracking-tight ${
            phase >= 3 ? "text-gray-800" : "text-white/95"
          }`}
          style={{
            fontFamily: "'Noto Sans KR', 'Apple SD Gothic Neo', sans-serif",
            textShadow:
              phase >= 3
                ? "0 2px 4px rgba(0,0,0,0.1)"
                : "0 2px 8px rgba(0,0,0,0.3)",
          }}
        >
          <motion.span
            key="greeting"
            initial={{ opacity: 0, y: 100 }}
            animate={{
              opacity: phase >= 2.2 ? 1 : 0,
              y: phase >= 2.2 ? 0 : 100,
            }}
            transition={{
              duration: 1.5,
              ease: [0.23, 1, 0.32, 1],
            }}
            className="inline-block leading-relaxed"
          >
            제 포트폴리오를 소개할 수 있어 영광입니다
          </motion.span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{
            opacity: phase >= 2.5 ? 1 : 0,
            y: phase >= 2.5 ? 0 : 50,
          }}
          transition={{
            duration: 3,
            ease: [0.23, 1, 0.32, 1],
            delay: 0.5,
          }}
          className={`mt-8 text-xl md:text-2xl font-light tracking-normal ${
            phase >= 3 ? "text-gray-600" : "text-white/70"
          }`}
          style={{
            fontFamily: "'Noto Sans KR', 'Apple SD Gothic Neo', sans-serif",
          }}
        >
          <motion.span
            key="subtitle"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.5, delay: 0.8 }}
            className="inline-block"
          >
            프리미엄 웹 경험의 시작
          </motion.span>
        </motion.p>

        {/* 로딩 인디케이터 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: phase >= 3 ? 1 : 0 }}
          transition={{ duration: 3, delay: 1 }}
          className="mt-12 flex items-center justify-center"
        >
          <div className="flex space-x-3">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className={`w-2 h-2 rounded-full ${
                  phase >= 3 ? "bg-gray-400" : "bg-white"
                }`}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 1.5,
                  delay: i * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            ))}
          </div>
          <span
            className={`ml-4 text-sm ${
              phase >= 3 ? "text-gray-500" : "text-white/60"
            }`}
          >
            프리미엄 콘텐츠 준비 중
          </span>
        </motion.div>
      </div>
    </motion.div>
  );

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          ref={containerRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{
            opacity: 0,
            transition: {
              duration: 2.5,
              ease: [0.23, 1, 0.32, 1],
              delay: 0.8,
            },
          }}
          className={`fixed inset-0 z-[70] overflow-hidden ${
            isTransitioning ? "cursor-none" : ""
          }`}
          style={{ perspective: 1000 }}
        >
          {/* 프리미엄 배경 */}
          <motion.div
            initial={{
              background:
                "radial-gradient(ellipse at center, #0a0a0a 0%, #000000 100%)",
            }}
            animate={{
              background:
                phase >= 3
                  ? "radial-gradient(ellipse at center, #f8f8f8 0%, #f0f0f0 100%)"
                  : phase >= 2
                  ? "radial-gradient(ellipse at center, #2a2a2a 0%, #1a1a1a 100%)"
                  : "radial-gradient(ellipse at center, #0a0a0a 0%, #000000 100%)",
            }}
            transition={{ duration: 3, ease: [0.23, 1, 0.32, 1] }}
            className="absolute inset-0"
          >
            <BackgroundEffect />

            {/* 고급 오버레이 */}
            <div className="absolute inset-0">
              <div
                className={`absolute inset-0 ${
                  phase >= 3
                    ? "bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.05),rgba(248,248,248,0))]"
                    : "bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.2),rgba(0,0,0,0))]"
                }`}
              />
            </div>
          </motion.div>

          {/* 3D 메인 컨텐츠 */}
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{ transformStyle: "preserve-3d" }}
          >
            <MainObject />
            <TextContent />
          </div>

          {/* 프리미엄 프로그레스 인디케이터 */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            exit={{ scaleX: 0, opacity: 0 }}
            transition={{ duration: 7, ease: "linear" }}
            className="absolute bottom-0 left-0 right-0 h-px origin-left"
            style={{
              background:
                phase >= 3
                  ? "linear-gradient(90deg, transparent, rgba(150,150,150,0.5), transparent)"
                  : "linear-gradient(90deg, transparent, rgba(120,119,198,0.7), transparent)",
            }}
          />

          {/* 하단 텍스트 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{
              opacity: phase >= 3.5 ? 0 : phase >= 1 ? 1 : 0,
              y: phase >= 3.5 ? -20 : 0,
            }}
            transition={{ duration: 2, ease: [0.23, 1, 0.32, 1] }}
            className={`absolute bottom-16 left-0 right-0 text-center text-sm font-light tracking-widest ${
              phase >= 3 ? "text-gray-500" : "text-white/40"
            }`}
          >
            {phase >= 3
              ? "프리미엄 콘텐츠 로딩 중"
              : "PREMIUM KOREAN PORTFOLIO EXPERIENCE"}
          </motion.div>

          {/* 3D 커서 효과 */}
          <motion.div
            animate={{
              x: mousePos.current.x - 10,
              y: mousePos.current.y - 10,
              scale: phase >= 4 ? 0 : 1,
              opacity: phase >= 4 ? 0 : 0.6,
            }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="fixed w-5 h-5 rounded-full pointer-events-none"
            style={{
              background:
                phase >= 3
                  ? "radial-gradient(circle, rgba(100,100,100,0.3), transparent)"
                  : "radial-gradient(circle, rgba(255,255,255,0.3), transparent)",
              backdropFilter: "blur(2px)",
              border: `1px solid ${
                phase >= 3 ? "rgba(100,100,100,0.3)" : "rgba(255,255,255,0.3)"
              }`,
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default IntroOverlay;
