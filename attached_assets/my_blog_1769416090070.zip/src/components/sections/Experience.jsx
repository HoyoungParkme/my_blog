export default function Experience({ lang }) {
  const content = {
    ko: {
      title: "주요 경험",
      highlightsTitle: "프로젝트 중심 경험",
      highlights: [
        "현대글로비스 ERP 데이터 기반 KPI 설계 및 실시간 대시보드 구축",
        "삼성물산 Tableau REST API + FabricX + LangChain으로 AI Agent PoC 구현",
        "현대모비스 COBOL → Java 전환 에이전트 개발 PoC",
        "이상 패턴 탐지 모델에 RAG 개념을 접목해 영상 메타를 Vector DB로 관리하고, 학습 없이 유사 영상 탐지 연구",
      ],
    },
  };

  const t = content[lang] || content.ko;

  return (
    <section id="experience" className="py-20 bg-neutral-100 text-black">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 border-b border-zinc-400 pb-2">
          {t.title}
        </h2>

        <div className="mt-6">
          <h3 className="text-xl font-semibold mb-3">{t.highlightsTitle}</h3>
          <ul className="list-disc list-inside space-y-2 text-zinc-700">
            {t.highlights.map((item, idx) => (
              <li key={idx}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
