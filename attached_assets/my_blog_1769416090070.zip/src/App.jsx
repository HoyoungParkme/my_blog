import { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Hero from "./components/sections/Hero";
import About from "./components/sections/About";
import Projects from "./components/sections/Projects";
import Experience from "./components/sections/Experience";
import FloatingNav from "./components/common/FloatingNav";
import Footer from "./components/common/Footer";
import AnimatedSection from "./components/common/AnimatedSection";
import ProjectList from "./pages/ProjectList";
// ProjectDetail 사용 안 함 (노션 링크로 대체)

const translations = {
  ko: {
    langName: "한국어",
    toggle: "English",
    intro: "안녕하세요, 데이터 기반 올라운더 개발자 박호영입니다.",
  },
  en: {
    langName: "English",
    toggle: "한국어",
    intro: "Hi, I'm Hoyoung Park, a data-driven all-round developer.",
  },
};

function HomePage({ lang, setLang, t }) {
  return (
    <>
      <Hero intro={t.intro} />
      <AnimatedSection>
        <About lang={lang} />
      </AnimatedSection>
      <AnimatedSection>
        <Experience lang={lang} />
      </AnimatedSection>
      <AnimatedSection>
        <Projects lang={lang} />
      </AnimatedSection>
      <Footer />
    </>
  );
}

function App() {
  const [lang, setLang] = useState("ko");
  const t = translations[lang];

  return (
    <Router basename={process.env.PUBLIC_URL || "/my_blog"}>
      <div className="font-sans text-black bg-neutral-100">
        <Routes>
          <Route
            path="/"
            element={<HomePage lang={lang} setLang={setLang} t={t} />}
          />
          <Route path="/projects" element={<ProjectList lang={lang} />} />
          {/* 프로젝트 상세 라우트는 노션 링크로 대체되었습니다 */}
        </Routes>

        <FloatingNav />

        {/* Language toggle removed as requested */}
      </div>
    </Router>
  );
}

export default App;
