// src/data/projectData.js
// 공용 데이터 소스: src/data/projects/*.json 파일을 자동으로 불러와 정적 데이터로 제공합니다.

const notionLink =
  "https://www.notion.so/test-2dcacd78299e8046909fce0dbc35efea?source=copy_link";

const projectModules = require.context("./projects", false, /\.json$/);

function loadProjectModules() {
  const grouped = { 실무: [], 연구: [] };

  projectModules.keys().forEach((key) => {
    const data = projectModules(key);
    const fileId = key.replace("./", "").replace(".json", "");
    const item = {
      id: data.id || fileId,
      type: data.type || "실무",
      title: data.title || "",
      period: data.period || "",
      description: data.description || "",
      stack: data.stack || [],
      link: data.link || notionLink,
    };
    if (!grouped[item.type]) grouped[item.type] = [];
    grouped[item.type].push(item);
  });

  return grouped;
}

export const projectsKo = loadProjectModules();

// 정적 데이터 반환 (노션 링크로 이동하므로 메타 정보만 유지)
export async function loadProjectsFromMarkdown() {
  return projectsKo;
}
