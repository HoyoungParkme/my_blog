## 페이지별 기능 요약

### 홈 (`/`)
- 섹션 구성: Hero → About → Experience → Projects → Footer
- `Hero`: IntroOverlay 1회 재생 후 히어로 카피 노출, 직군 워딩 오버레이
- `About`: 자기소개/핵심 포지셔닝 + 프로필 이미지
- `Experience`: 기술 스택 배지 + 주요 경험 리스트
- `Projects`: 프로젝트 카테고리 필터(전체/실무/연구), 카드 미리보기 4열 그리드(반응형)
- `FloatingNav`: 이메일/전화 복사, Top 스크롤 버튼 (모바일 우측 하단 고정)

### 프로젝트 목록 (`/projects`)
- `ProjectList`: 카테고리 필터, 로딩 상태, 데이터 미존재 시 빈 상태 메시지
- 카드 클릭 시 `/:projectId` 상세로 이동

### 프로젝트 상세 (`/projects/:projectId`)
- 현재 미사용(노션 공유 링크로 대체), 라우트도 제거됨

## 데이터 파이프라인
- 소스: `src/data/projects/*.json` (id, type, title, period, description, stack, link)
- 로더: `src/data/projectData.js`에서 `require.context`로 JSON을 자동 로드하고 type별로 그룹화
- 소비자: `loadProjectsFromMarkdown()`가 정적 데이터(`projectsKo`)를 반환해 목록/섹션에서 사용
- 프로젝트 상세는 사용하지 않고, 카드 클릭 시 노션 공유 링크로 새 탭 이동

## 컴포넌트 책임 분리
- `components/sections`: 랜딩 페이지 전용 섹션 단위(Hero, About, Experience, Projects)
- `components/common`: 레이아웃/공통 UI(FloatingNav, Footer, IntroOverlay, 애니메이션 래퍼)
- `components/projects`: 프로젝트 카드/상세/노션 블록 UI
