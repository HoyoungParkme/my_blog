## 폴더 구조 개요

- 리액트 18 + React Router 7 기반 포트폴리오
- 프로젝트/페이지/공통 UI를 분리해 재사용성을 높임
- 프로젝트 데이터는 `public/projects/*.md` → `src/utils` 파이프라인으로 로드

### 상위 트리
```
my_blog/
├─ src/
│  ├─ App.jsx                # 라우팅 및 페이지 조립
│  ├─ assets/                # 정적 이미지, 아이콘 등
│  ├─ components/
│  │  ├─ common/             # 공통 UI
│  │  │  ├─ AnimatedSection.jsx
│  │  │  ├─ FadeInSection.jsx
│  │  │  ├─ FloatingNav.jsx
│  │  │  ├─ Footer.jsx
│  │  │  └─ IntroOverlay.jsx
│  │  ├─ projects/           # 프로젝트 뷰 전용 컴포넌트
│  │  │  ├─ NotionBlocks.jsx
│  │  │  ├─ ProjectCard.jsx
│  │  │  └─ ProjectDetailContent.jsx
│  │  └─ sections/           # 랜딩/섹션 컴포넌트
│  │     ├─ About.jsx
│  │     ├─ Experience.jsx
│  │     ├─ Hero.jsx
│  │     └─ Projects.jsx
│  ├─ data/                  # 프로젝트 데이터 로더
│  ├─ pages/                 # 라우트 단위 페이지
│  │  ├─ ProjectDetail.jsx
│  │  └─ ProjectList.jsx
│  ├─ utils/                 # (현재 비어 있음, 추후 공용 유틸 배치 가능)
│  ├─ App.css, index.css, index.js
│  └─ ...
├─ public/
│  └─ (정적 자산만 사용, 프로젝트 마크다운 폴더는 제거)
└─ docs/                     # 문서 모음
```

### 의존성/런타임 메모
- Node 20.x (nvm으로 관리), npm 10.x
- 빌드/실행: `npm start`, `npm run build`
- 데이터 로딩은 `PUBLIC_URL`(gh-pages) 기준 fetch를 사용하므로 정적 배포 시 `public/projects` 경로 유지 필수
